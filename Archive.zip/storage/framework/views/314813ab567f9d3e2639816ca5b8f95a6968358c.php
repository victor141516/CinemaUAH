<?php $__env->startSection('extra-css'); ?>
    <style type="text/css" media="screen">
        .film {
            min-height: 340px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Películas
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('public.common.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="jumbotron">
        <div class="row">
            <?php $__currentLoopData = $films; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $film): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <div class="col-md-3 col-sm-6 col-xs-12 text-center film">
                    <a href="<?php echo e(url('film/'.$film->id)); ?>">
                        <img src=<?php if($film->has_image): ?> "/img/<?php echo e($film->id); ?>.jpg" <?php else: ?> "/img/default.jpg" <?php endif; ?> alt="">
                        <h4><?php echo e($film->name); ?></h4>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>