<?php $__env->startSection('extra-css'); ?>
    <style type="text/css" media="screen">
        .fila {
            display: flex;
            min-height: 24px;
        }
        .columna {
            flex-basis: 100%;
            background-position: center;
        }
        .free {
            background-image: url('<?php echo e(url('/img/free_seat.png')); ?>');
            background-repeat: no-repeat;
        }
        .taken {
            background-image: url('<?php echo e(url('/img/taken_seat.png')); ?>');
            background-repeat: no-repeat;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Películas
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('admin.common.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

        <div class="row">
            <div class="col-xs-12" id="theater">
                <div class="row text-center" style="background-color: grey;">
                    <strong>Pantalla</strong>
                </div>
                <?php for($i = 0; $i <= $projection->theater->n_rows; $i++): ?>
                    <div class="row fila" id="fila<?php echo e($i); ?>">
                        <?php for($j = 0; $j <= $projection->theater->n_columns; $j++): ?>
                            <div class="columna text-center <?php if(in_array($i . '-' . $j, $seats)): ?> taken <?php else: ?> free <?php endif; ?> <?php echo e('seat-' . $i . '-' . $j); ?>" id="columna<?php echo e($j); ?>"></div>
                        <?php endfor; ?>
                    </div>
                <?php endfor; ?>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
    <script type="text/javascript">
        $("[id^=columna]").click(function(){
            var seat_selector = $(this);
            if(seat_selector.hasClass('free')) {
                state = 'taken';
            } else {
                state = 'free';
            }
            seat = seat_selector.attr('class').toString().split('seat-')[1].split(' ')[0].split('-');
            $.ajax({
                type: 'post',
                url: '/api/change_seat',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data: {
                    projection: <?php echo e($projection->id); ?>,
                    row: seat[0],
                    column: seat[1],
                    state: state
                },
                success: function(data, textStatus, xhr) {
                    if(data == 0) {
                        seat_selector.addClass('taken');
                        seat_selector.removeClass('free')
                    } else if (data == 1) {
                        seat_selector.addClass('free');
                        seat_selector.removeClass('taken')
                    }
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>