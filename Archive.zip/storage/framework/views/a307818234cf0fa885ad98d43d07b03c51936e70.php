<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">Cinema UAH</a>
    </div>
    <div id="navbar" class="collapse navbar-collapse">
      <ul class="nav navbar-nav">
        <!--Rol User-->
        <li  <?php if(app('request')->is('films')): ?> class="active" <?php endif; ?>>
          <a href="<?php echo e(url('/')); ?>">Películas</a>
        </li>
        <li  <?php if(app('request')->is('theater')): ?> class="active" <?php endif; ?>>
          <a href="<?php echo e(url('/theater')); ?>">Salas</a>
        </li>
        <li  <?php if(app('request')->is('reservations')): ?> class="active" <?php endif; ?>>
          <a href="<?php echo e(url('/reservations')); ?>">Consultar reservas</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
