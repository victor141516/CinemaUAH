<?php $__env->startSection('extra-css'); ?>
    <style type="text/css" media="screen">
        .jumbotron p {
            font-size: 16px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    <?php echo e($film->name); ?> (<?php echo e($film->year); ?>)
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('public.common.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-xs-12">
            <h3><?php echo e($film->name); ?> <span>(<?php echo e($film->year); ?>)</span></h3>
        </div>
        <div class="col-xs-12" style="font-style: italic;">
            <?php echo e($film->original_title); ?> (título original)
        </div>
        <div class="col-xs-12">
            <?php echo e($film->age_rating); ?> | <?php echo e($film->minutes_duration); ?> mins. | <?php echo e($film->genre); ?>

        </div>
    </div>
    <div class="row" style="padding-top: 15px;">
        <div class="col-sm-4 col-xs-12 text-center">
            <img src=<?php if($film->has_image): ?> "/img/films/<?php echo e($film->id); ?>.jpg" <?php else: ?> "/img/default.jpg" <?php endif; ?> alt="<?php echo e($film->name); ?>">
        </div>
        <div class="col-sm-8 col-xs-12">
            <p>
                <strong>Sinopsis: </strong>
                <?php echo e($film->synopsis); ?>

            </p>
            <p>
                <strong>Director: </strong>
                <?php echo e($film->director); ?>

            </p>
            <p>
                <strong>Productor: </strong>
                <?php echo e($film->producer); ?>

            </p>
            <p>
                <strong>Navionalidad: </strong>
                <?php echo e($film->country); ?>

            </p>
            <p>
                <a href="<?php echo e($film->website); ?>" title="<?php echo e($film->name); ?>"><strong>Página Web</strong></a>
            </p>
            <?php if($film->others != ''): ?>
                <p>
                    <strong>Otros: </strong>
                    <?php echo e($film->others); ?>

                </p>
            <?php endif; ?>
            <p>
                <?php echo $__env->make('public.common.film_projections', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </p>
        </div>
    </div>
    <div class="row" style="padding-top: 15px;">
        <div class="col-xs-12">
            <h4>Opiniones de Usuarios</h4>
        </div>
    </div>

    <?php if(count($film->comments) == 0 && Auth::check()): ?>
        <div class="row">
            <div class="col-xs-12 col-md-8 col-md-offset-2">
                <div class="alert alert-warning">
                    Aún no tenemos comentarios para esta película, añade el tuyo :)
                </div>
            </div>
        </div>
    <?php endif; ?>

    <?php $__currentLoopData = $film->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <div class="row">
            <div class="col-xs-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Opinión por <?php echo e($comment->user->name); ?>

                    </div>
                    <div class="panel-body">
                        <p><?php echo e($comment->text); ?></p>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

    <?php if(Auth::check()): ?>
        <div class="row">
            <div class="col-xs-12">
                <form action="<?php echo e(url('/comment')); ?>" method="post" accept-charset="utf-8">
                    <input type="hidden" name="film_id" value="<?php echo e($film->id); ?>">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="comment" class="control-label">Comentario</label>
                        <textarea class="form-control" rows="3" id="comment" name="comment"></textarea>
                    </div>
                    <div class="form-group text-right">
                        <button type="submit" class="btn btn-primary">Añadir comentario</button>
                    </div>
                </form>
            </div>
        </div>
    <?php else: ?>
        <div class="row">
            <div class="col-xs-12 col-md-8 col-md-offset-2">
                <div class="alert alert-warning">
                    <a href="<?php echo e(url('auth/login')); ?>" title="Iniciar sesión"><strong>Inicia sesión</strong></a> o <a href="<?php echo e(url('register')); ?>" title="Registrarse"><strong>regístrate</strong></a> para dejar un comentario.
                </div>
            </div>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>