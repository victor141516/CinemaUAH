<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, user-scalable=no" />
    <?php echo $__env->yieldContent('meta'); ?>

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <link href="<?php echo e(url('favicon/favicon.ico')); ?>" rel="icon" type="image/x-icon" />

    <style type="text/css" media="screen">
        body {
            padding-top: 70px;
        }
    </style>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/bootstrap.min.css')); ?>">
    <?php echo $__env->yieldContent('extra-css'); ?>
</head>
<body>
    <?php echo $__env->yieldContent('navbar'); ?>
    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <script type="text/javascript" src="<?php echo e(url('js/jquery-3.1.1.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('js/bootstrap.min.js')); ?>"></script>
    <?php echo $__env->yieldContent('extra-js'); ?>
</body>
</html>
