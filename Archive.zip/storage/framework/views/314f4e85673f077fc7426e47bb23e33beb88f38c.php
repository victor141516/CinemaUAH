<?php $__env->startSection('extra-css'); ?>
    <style type="text/css" media="screen">
        a {
            color: #424242;
        }
        .film {
            min-height: 340px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Proyecciones
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('public.common.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <?php $__currentLoopData = $projections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projection): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <div class="col-md-3 col-sm-4 col-xs-12 text-center film">
                <a href="<?php echo e(url('admin/manage_tickets/' . $projection->id . '/select_seats')); ?>">
                    <img src=<?php if($projection->film->has_image): ?> "/img/<?php echo e($projection->film->id); ?>.jpg" <?php else: ?> "/img/default.jpg" <?php endif; ?> alt="">
                    <h4><?php echo e($projection->film->name); ?> (<?php echo e($projection->begin); ?>)</h4>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>