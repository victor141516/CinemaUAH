<?php $__env->startSection('title'); ?>
    Crear pelicula
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('admin.common.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-xs-12">
            <div class="alert alert-warning hidden"></div>
        </div>
    </div>

    <form action="<?php echo e(url('/admin/add_film')); ?>" method="post" accept-charset="utf-8">
        <?php echo e(csrf_field()); ?>

        <div class="row">
            <div class="col-xs-12 text-right">
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </div>
        </div>

        <?php echo $__env->make('admin.common.addOrEdit_film', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
    <script src="/js/image-upload.js" type="text/javascript" charset="utf-8" async defer></script>
    <script type="text/javascript">
        $("#name").bind('input', function() {
            if (!($(this).hasClass('done'))) {
                $(this).addClass('done');
                $.ajax({
                    url: 'placeholder_film',
                    type: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data: {'name': $(this).val()},
                })
                .done(function(film_id) {
                    $("#id").val(film_id);
                    $(".image-place").removeClass('hidden');
                });    
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>