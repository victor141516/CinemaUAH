<?php $__env->startSection('title'); ?>
    Editar (<?php echo e($film->name); ?>)
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('admin.common.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <form action="<?php echo e(url('/admin/edit_film/'. $film->id)); ?>" method="post" accept-charset="utf-8">
        <div class="row">
            <div class="col-xs-12 text-right">
                <div class="form-group">
                    <a href="<?php echo e(url('admin/manage_projections/'. $film->id)); ?>" class="btn btn-info">Proyecciones</a>
                    <a href="<?php echo e(url('admin/delete_film/'. $film->id)); ?>" class="btn btn-danger confirmation">Borrar</a>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </div>
        </div>

        <?php echo $__env->make('admin.common.addOrEdit_film', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
    <script src="/js/image-upload.js" type="text/javascript" charset="utf-8" async defer></script>
    <script type="text/javascript">
        $('.confirmation').on('click', function () {
            return confirm('Vas a borrar esta película, ¿estás seguro?');
        });
        $(".image-place").removeClass('hidden');
        
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>