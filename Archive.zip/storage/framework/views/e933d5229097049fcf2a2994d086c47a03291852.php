<div class="row">
    <div class="col-md-4 col-sm-6 col-xs-12">
        <div class="form-group">
            <label for="name" class="control-label">Título</label>
            <input class="form-control" type="text" id="name" name="name" value="<?php echo e($film->name); ?>">
        </div>
        <div class="form-group">
            <label for="synopsis" class="control-label">Sinopsis</label>
            <textarea class="form-control" rows="4" id="synopsis" name="synopsis"><?php echo e($film->synopsis); ?></textarea>
        </div>
        <div class="form-group">
            <label for="website" class="control-label">Página Oficial</label>
            <input class="form-control" type="text" id="website" name="website" value="<?php echo e($film->website); ?>">
        </div>
        <div class="form-group">
            <label for="original_title" class="control-label">Título original</label>
            <input class="form-control" type="text" id="original_title" name="original_title" value="<?php echo e($film->original_title); ?>">
        </div>
        <div class="form-group">
            <label for="genre" class="control-label">Género</label>
            <select class="form-control" id="genre" name="genre">
                <option <?php if($film->genre == ''): ?> selected <?php endif; ?>>Selecciona el género</option>
                <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $each): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <option value="<?php echo e($each); ?>" <?php if($film->genre == $each): ?> selected="selected" <?php endif; ?>><?php echo e($each); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="country" class="control-label">Nacionalidad</label>
            <input class="form-control" type="text" id="country" name="country" value="<?php echo e($film->country); ?>">
        </div>
    </div>
    <div class="col-md-4 col-sm-6 col-xs-12">
        <div class="form-group">
            <label for="minutes_duration" class="control-label">Duración</label>
            <input class="form-control" type="number" id="minutes_duration" name="minutes_duration" value="<?php echo e($film->minutes_duration); ?>">
        </div>
        <div class="form-group">
            <label for="year" class="control-label">Año</label>
            <input class="form-control" type="number" id="year" name="year" value="<?php echo e($film->year); ?>">
        </div>
        <div class="form-group">
            <label for="producer" class="control-label">Distribuidora</label>
            <input class="form-control" type="text" id="producer" name="producer" value="<?php echo e($film->producer); ?>">
        </div>
        <div class="form-group">
            <label for="Director" class="control-label">Director</label>
            <input class="form-control" type="text" id="Director" name="director" value="<?php echo e($film->director); ?>">
        </div>
        <div class="form-group">
            <label for="actors" class="control-label">Actores</label>
            <input class="form-control" type="text" id="actors" name="actors" value="<?php echo e($actors); ?>">
        </div>
        <div class="form-group">
            <label for="age_rating" class="control-label">Clasificación</label>
            <select class="form-control" id="age_rating" name="age_rating">
                <option <?php if($film->age_rating == ''): ?> selected <?php endif; ?>>Selecciona la edad</option>
                <?php $__currentLoopData = $age_ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $age_rating): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <option value="<?php echo e($age_rating); ?>" <?php if($film->age_rating == $age_rating): ?> selected <?php endif; ?>><?php echo e($age_rating); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="others" class="control-label">Datos</label>
            <input class="form-control" type="text" id="others" name="others" value="<?php echo e($film->others); ?>">
        </div>
        <input type="hidden" name="id" id="id" value=<?php echo e(@(isset($film)) ? $film->id : "placeholder"); ?>>
        <input type="hidden" name="has_image" id="has_image" value=<?php echo e(isset($film) ? ($film->has_image ? "1" : "0") : "0"); ?>>
        <?php echo e(csrf_field()); ?>

    </div>
    <div class="col-md-4 col-sm-12 hidden image-place">
        <div id="holder">
            <?php if($film->has_image): ?>
                <img src="/img/films/<?php echo e($film->id); ?>.jpg" alt="<?php echo e($film->name); ?>">
            <?php else: ?>
                <p>Suelta la carátula aquí</p>
            <?php endif; ?>
        </div>
        <p id="upload" class="hidden">
            <label>Drag &amp; drop not supported, but you can still upload via this input field:<br>
                <input type="file">
            </label>
        </p>
        <p id="filereader">File API &amp; FileReader API not supported</p>
        <p id="formdata">XHR2's FormData is not supported</p>
    </div>
</div>
