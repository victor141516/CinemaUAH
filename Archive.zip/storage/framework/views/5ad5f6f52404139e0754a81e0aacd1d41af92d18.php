<div class="row mrg-top">
    <div class="col-xs-12 col-md-8 col-md-offset-2">
        <div class="alert alert-success hidden">
            <?php if(session('success')): ?> <?php echo e(session('success')); ?> <?php endif; ?>
        </div>
    </div>
</div>
