<?php $__env->startSection('title'); ?>
    Películas
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('admin.common.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('messages.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('messages.warning', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('messages.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php if($films->count() == 0): ?>
        <div class="row">
            <div class="col-xs-12 col-md-8 col-md-offset-2">
                <div class="alert alert-warning">
                    <strong>¡Atención!</strong> Aún no hay películas disponibles, pulsa <a href="<?php echo e(url('admin/add_film')); ?>" title="crear película">aquí</a> para crear una.
                </div>
            </div>
        </div>
    <?php endif; ?>

    <?php echo $__env->make('common.film_list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>