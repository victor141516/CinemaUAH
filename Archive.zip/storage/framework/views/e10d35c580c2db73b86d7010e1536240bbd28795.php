<?php $__env->startSection('title'); ?>
    Películas
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('public.common.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <?php $__currentLoopData = $films; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $film): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <div class="col-md-3 col-sm-4 col-xs-12 text-center film">
            <?php if(Request::is('/')): ?>
                <a href="<?php echo e(url('film/'.$film->id)); ?>">
            <?php else: ?>
                <a href="<?php echo e(url('admin/edit_film/'.$film->id)); ?>">
            <?php endif; ?>
                    <img src=<?php if($film->has_image): ?> "/img/films/<?php echo e($film->id); ?>.jpg" <?php else: ?> "/img/default.jpg" <?php endif; ?> alt="">
                    <h4><?php echo e($film->name); ?></h4>
                </a>
                <?php echo $__env->make('public.common.film_projections', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>