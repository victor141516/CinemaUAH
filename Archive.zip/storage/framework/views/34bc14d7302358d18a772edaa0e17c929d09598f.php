<?php $__env->startSection('extra-css'); ?>
    <style type="text/css" media="screen">
        a {
            color: #424242;
        }
        .film {
            min-height: 340px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Proyecciones
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('admin.common.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <?php $__currentLoopData = $theaters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projections): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <div class="col-sm-6 col-xs-12">
                <ul class="list-group">
                    <a class="list-group-item active" href="#" title="Editar proyección"><?php echo e($projections->first()->theater->name); ?></a>
                    <?php $__currentLoopData = $projections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projection): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <a class="list-group-item" href="<?php echo e(url('admin/manage_tickets/' . $projection->id)); ?>">
                            <strong><?php echo e($projection->film->name); ?></strong> (<?php echo e($projection->begin); ?>)
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>