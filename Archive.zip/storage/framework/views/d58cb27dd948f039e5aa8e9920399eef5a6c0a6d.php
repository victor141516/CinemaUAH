<?php $__currentLoopData = $film->projections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projection): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	<a href="/seats/<?php echo e($projection->id); ?>"><?php echo e($projection->getBeginHour()); ?></a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>