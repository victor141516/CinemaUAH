<?php $__env->startSection('title'); ?>
    Administrar salas
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('admin.common.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if($theaters->count() == 0): ?>
        <div class="row">
            <div class="col-xs-12 col-md-8 col-md-offset-2">
                <div class="alert alert-warning">
                    <strong>¡Atención!</strong> Aún no hay salas disponibles, pulsa <a href="<?php echo e(url('admin/add_theater')); ?>" title="crear sala">aquí</a> para crear una.
                </div>
            </div>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-sm-4 col-sm-offset-4 col-xs-12">
            <ul class="list-group">
                <?php $__currentLoopData = $theaters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theater): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <a class="list-group-item" href="<?php echo e(url('admin/edit_theater/'. $theater->id)); ?>" title="Editar sala"><?php echo e($theater->name); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </ul>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>