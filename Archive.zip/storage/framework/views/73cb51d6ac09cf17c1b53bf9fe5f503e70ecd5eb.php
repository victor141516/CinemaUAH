<div class="row">
    <div class="col-xs-12 col-md-8 col-md-offset-2">
        <div class="alert alert-danger hidden">
            <?php if(session('error')): ?> <?php echo e(session('error')); ?> <?php endif; ?>
        </div>
    </div>
</div>

<?php if(isset($messages)): ?>
<div class="row mrg-top">
    <div class="col-md-12">
        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $ms): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <div class="alert alert-<?php echo e($type); ?>">
                <ul>
                <?php $__currentLoopData = $ms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <li><?php echo e($message); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </ul>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </div>
</div>
<?php endif; ?>

<?php if(count($errors) > 0): ?>
<div class="row mrg-top">
    <div class="col-md-12">
        <div class="alert alert-danger">
            <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </ul>
        </div>
    </div>
</div>
<?php endif; ?>
