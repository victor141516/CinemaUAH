@extends('master')

@section('title')
    Admin home
@endsection

@section('navbar')
    @include('admin.common.navigation')
@endsection

@section('content')

    <div class="row">
        <div class="col-xs-12 text-left">
            <h3>Estadísticas (informes?):</h3>
        </div>
    </div>

@endsection
