<div class="row">
    <div class="col-xs-12 col-md-8 col-md-offset-2">
        <div class="alert alert-warning hidden">
            @if (session('warning')) {{ session('warning') }} @endif
        </div>
    </div>
</div>
