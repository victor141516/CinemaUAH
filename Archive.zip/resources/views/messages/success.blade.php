<div class="row mrg-top">
    <div class="col-xs-12 col-md-8 col-md-offset-2">
        <div class="alert alert-success hidden">
            @if (session('success')) {{ session('success') }} @endif
        </div>
    </div>
</div>
